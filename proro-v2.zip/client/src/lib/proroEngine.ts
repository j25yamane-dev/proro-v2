/**
 * Proro V2 - C++ Interpreter & 2D Physics Engine
 * 
 * このファイルは以下の機能を提供します：
 * 1. C++風コードの字句解析・構文解析
 * 2. コマンド実行エンジン（forward, turnLeft, etc.）
 * 3. 2D物理シミュレーション（位置、回転、衝突）
 * 4. ステップ実行・デバッグ情報の提供
 */

// ============================================================================
// 型定義
// ============================================================================

export interface ProroState {
  x: number;
  y: number;
  angle: number; // 度数法 (0 = 上向き, 90 = 右, 180 = 下, 270 = 左)
  speed: number; // 1-100
  isMoving: boolean;
  sensorDetected: boolean;
}

export interface ExecutionStep {
  lineNumber: number;
  command: string;
  state: ProroState;
  timestamp: number;
}

export interface ExecutionResult {
  success: boolean;
  error?: string;
  errorLine?: number;
  steps: ExecutionStep[];
  finalState: ProroState;
}

export interface CanvasConfig {
  width: number;
  height: number;
  gridSize: number;
}

// ============================================================================
// トークン定義
// ============================================================================

enum TokenType {
  // キーワード
  IF = "IF",
  ELSE = "ELSE",
  FOR = "FOR",
  WHILE = "WHILE",
  INT = "INT",
  VOID = "VOID",

  // 識別子・リテラル
  IDENTIFIER = "IDENTIFIER",
  NUMBER = "NUMBER",
  STRING = "STRING",

  // 演算子・区切り文字
  LPAREN = "LPAREN",
  RPAREN = "RPAREN",
  LBRACE = "LBRACE",
  RBRACE = "RBRACE",
  SEMICOLON = "SEMICOLON",
  COMMA = "COMMA",
  ASSIGN = "ASSIGN",
  EQ = "EQ",
  NEQ = "NEQ",
  LT = "LT",
  GT = "GT",
  LTE = "LTE",
  GTE = "GTE",
  PLUS = "PLUS",
  MINUS = "MINUS",
  MUL = "MUL",
  DIV = "DIV",
  MOD = "MOD",
  AND = "AND",
  OR = "OR",
  NOT = "NOT",
  INCREMENT = "INCREMENT",
  DECREMENT = "DECREMENT",

  // その他
  EOF = "EOF",
  NEWLINE = "NEWLINE",
}

interface Token {
  type: TokenType;
  value: string | number;
  lineNumber: number;
}

// ============================================================================
// レクサー（字句解析）
// ============================================================================

class Lexer {
  private input: string;
  private position: number = 0;
  private lineNumber: number = 1;
  private tokens: Token[] = [];

  constructor(input: string) {
    this.input = input;
  }

  private currentChar(): string | null {
    return this.position < this.input.length ? this.input[this.position] : null;
  }

  private peekChar(offset: number = 1): string | null {
    const pos = this.position + offset;
    return pos < this.input.length ? this.input[pos] : null;
  }

  private advance(): void {
    if (this.currentChar() === "\n") {
      this.lineNumber++;
    }
    this.position++;
  }

  private skipWhitespace(): void {
    while (this.currentChar() && /\s/.test(this.currentChar()!)) {
      this.advance();
    }
  }

  private skipComment(): void {
    if (this.currentChar() === "/" && this.peekChar() === "/") {
      while (this.currentChar() && this.currentChar() !== "\n") {
        this.advance();
      }
    }
  }

  private readNumber(): number {
    let numStr = "";
    while (this.currentChar() && /\d/.test(this.currentChar()!)) {
      numStr += this.currentChar();
      this.advance();
    }
    return parseInt(numStr, 10);
  }

  private readIdentifier(): string {
    let ident = "";
    while (
      this.currentChar() &&
      /[a-zA-Z0-9_]/.test(this.currentChar()!)
    ) {
      ident += this.currentChar();
      this.advance();
    }
    return ident;
  }

  private readString(): string {
    const quote = this.currentChar();
    this.advance();
    let str = "";
    while (this.currentChar() && this.currentChar() !== quote) {
      str += this.currentChar();
      this.advance();
    }
    if (this.currentChar() === quote) {
      this.advance();
    }
    return str;
  }

  private getKeywordOrIdentifier(
    word: string
  ): { type: TokenType; value: string } {
    const keywords: Record<string, TokenType> = {
      if: TokenType.IF,
      else: TokenType.ELSE,
      for: TokenType.FOR,
      while: TokenType.WHILE,
      int: TokenType.INT,
      void: TokenType.VOID,
    };
    const type = keywords[word] || TokenType.IDENTIFIER;
    return { type, value: word };
  }

  tokenize(): Token[] {
    while (this.position < this.input.length) {
      this.skipWhitespace();

      if (this.currentChar() === "/") {
        this.skipComment();
        continue;
      }

      const char = this.currentChar();
      if (!char) break;

      const line = this.lineNumber;

      if (/\d/.test(char)) {
        const num = this.readNumber();
        this.tokens.push({ type: TokenType.NUMBER, value: num, lineNumber: line });
      } else if (/[a-zA-Z_]/.test(char)) {
        const ident = this.readIdentifier();
        const { type, value } = this.getKeywordOrIdentifier(ident);
        this.tokens.push({ type, value, lineNumber: line });
      } else if (char === '"' || char === "'") {
        const str = this.readString();
        this.tokens.push({ type: TokenType.STRING, value: str, lineNumber: line });
      } else if (char === "(") {
        this.tokens.push({ type: TokenType.LPAREN, value: "(", lineNumber: line });
        this.advance();
      } else if (char === ")") {
        this.tokens.push({ type: TokenType.RPAREN, value: ")", lineNumber: line });
        this.advance();
      } else if (char === "{") {
        this.tokens.push({ type: TokenType.LBRACE, value: "{", lineNumber: line });
        this.advance();
      } else if (char === "}") {
        this.tokens.push({ type: TokenType.RBRACE, value: "}", lineNumber: line });
        this.advance();
      } else if (char === ";") {
        this.tokens.push({ type: TokenType.SEMICOLON, value: ";", lineNumber: line });
        this.advance();
      } else if (char === ",") {
        this.tokens.push({ type: TokenType.COMMA, value: ",", lineNumber: line });
        this.advance();
      } else if (char === "=" && this.peekChar() === "=") {
        this.tokens.push({ type: TokenType.EQ, value: "==", lineNumber: line });
        this.advance();
        this.advance();
      } else if (char === "=" && this.peekChar() !== "=") {
        this.tokens.push({ type: TokenType.ASSIGN, value: "=", lineNumber: line });
        this.advance();
      } else if (char === "!" && this.peekChar() === "=") {
        this.tokens.push({ type: TokenType.NEQ, value: "!=", lineNumber: line });
        this.advance();
        this.advance();
      } else if (char === "!") {
        this.tokens.push({ type: TokenType.NOT, value: "!", lineNumber: line });
        this.advance();
      } else if (char === "<" && this.peekChar() === "=") {
        this.tokens.push({ type: TokenType.LTE, value: "<=", lineNumber: line });
        this.advance();
        this.advance();
      } else if (char === "<") {
        this.tokens.push({ type: TokenType.LT, value: "<", lineNumber: line });
        this.advance();
      } else if (char === ">" && this.peekChar() === "=") {
        this.tokens.push({ type: TokenType.GTE, value: ">=", lineNumber: line });
        this.advance();
        this.advance();
      } else if (char === ">") {
        this.tokens.push({ type: TokenType.GT, value: ">", lineNumber: line });
        this.advance();
      } else if (char === "+" && this.peekChar() === "+") {
        this.tokens.push({ type: TokenType.INCREMENT, value: "++", lineNumber: line });
        this.advance();
        this.advance();
      } else if (char === "+") {
        this.tokens.push({ type: TokenType.PLUS, value: "+", lineNumber: line });
        this.advance();
      } else if (char === "-" && this.peekChar() === "-") {
        this.tokens.push({ type: TokenType.DECREMENT, value: "--", lineNumber: line });
        this.advance();
        this.advance();
      } else if (char === "-") {
        this.tokens.push({ type: TokenType.MINUS, value: "-", lineNumber: line });
        this.advance();
      } else if (char === "*") {
        this.tokens.push({ type: TokenType.MUL, value: "*", lineNumber: line });
        this.advance();
      } else if (char === "/") {
        this.tokens.push({ type: TokenType.DIV, value: "/", lineNumber: line });
        this.advance();
      } else if (char === "%") {
        this.tokens.push({ type: TokenType.MOD, value: "%", lineNumber: line });
        this.advance();
      } else if (char === "&" && this.peekChar() === "&") {
        this.tokens.push({ type: TokenType.AND, value: "&&", lineNumber: line });
        this.advance();
        this.advance();
      } else if (char === "|" && this.peekChar() === "|") {
        this.tokens.push({ type: TokenType.OR, value: "||", lineNumber: line });
        this.advance();
        this.advance();
      } else if (char === "\n") {
        this.tokens.push({ type: TokenType.NEWLINE, value: "\n", lineNumber: line });
        this.advance();
      } else {
        this.advance();
      }
    }

    this.tokens.push({ type: TokenType.EOF, value: "", lineNumber: this.lineNumber });
    return this.tokens;
  }
}

// ============================================================================
// パーサー（構文解析）
// ============================================================================

interface ASTNode {
  type: string;
  lineNumber: number;
  [key: string]: any;
}

class Parser {
  private tokens: Token[];
  private position: number = 0;

  constructor(tokens: Token[]) {
    this.tokens = tokens;
  }

  private currentToken(): Token {
    return this.tokens[this.position] || this.tokens[this.tokens.length - 1];
  }

  private peekToken(offset: number = 1): Token {
    return this.tokens[this.position + offset] || this.tokens[this.tokens.length - 1];
  }

  private advance(): void {
    this.position++;
  }

  private expect(type: TokenType): Token {
    const token = this.currentToken();
    if (token.type !== type) {
      throw new Error(
        `Expected ${type} but got ${token.type} at line ${token.lineNumber}`
      );
    }
    this.advance();
    return token;
  }

  private skipNewlines(): void {
    while (this.currentToken().type === TokenType.NEWLINE) {
      this.advance();
    }
  }

  parse(): ASTNode[] {
    const statements: ASTNode[] = [];
    this.skipNewlines();

    while (this.currentToken().type !== TokenType.EOF) {
      this.skipNewlines();
      if (this.currentToken().type === TokenType.EOF) break;

      const stmt = this.parseStatement();
      if (stmt) {
        statements.push(stmt);
      }
      this.skipNewlines();
    }

    return statements;
  }

  private parseStatement(): ASTNode | null {
    const token = this.currentToken();
    const lineNumber = token.lineNumber;

    if (token.type === TokenType.IF) {
      return this.parseIfStatement();
    } else if (token.type === TokenType.FOR) {
      return this.parseForStatement();
    } else if (token.type === TokenType.WHILE) {
      return this.parseWhileStatement();
    } else if (token.type === TokenType.LBRACE) {
      return this.parseBlock();
    } else if (token.type === TokenType.IDENTIFIER) {
      return this.parseExpressionStatement();
    } else {
      this.advance();
      return null;
    }
  }

  private parseIfStatement(): ASTNode {
    const lineNumber = this.currentToken().lineNumber;
    this.expect(TokenType.IF);
    this.expect(TokenType.LPAREN);
    const condition = this.parseExpression();
    this.expect(TokenType.RPAREN);
    this.skipNewlines();
    const thenBranch = this.parseStatement();
    let elseBranch = null;
    if (this.currentToken().type === TokenType.ELSE) {
      this.advance();
      this.skipNewlines();
      elseBranch = this.parseStatement();
    }
    return {
      type: "IfStatement",
      condition,
      thenBranch,
      elseBranch,
      lineNumber,
    };
  }

  private parseForStatement(): ASTNode {
    const lineNumber = this.currentToken().lineNumber;
    this.expect(TokenType.FOR);
    this.expect(TokenType.LPAREN);
    
    // 初期化式（int i = 0など）
    let init: ASTNode | null = null;
    if (this.currentToken().type === TokenType.INT) {
      this.advance();
      const name = (this.currentToken().value as string);
      this.advance();
      if (this.currentToken().type === TokenType.ASSIGN) {
        this.advance();
        const value = this.parseLogicalOr();
        init = {
          type: "Assignment",
          name,
          value,
          lineNumber: this.currentToken().lineNumber,
        };
      }
    } else {
      init = this.parseExpression();
    }
    
    this.expect(TokenType.SEMICOLON);
    const condition = this.parseExpression();
    this.expect(TokenType.SEMICOLON);
    const update = this.parseExpression();
    this.expect(TokenType.RPAREN);
    this.skipNewlines();
    const body = this.parseStatement();
    return {
      type: "ForStatement",
      init,
      condition,
      update,
      body,
      lineNumber,
    };
  }

  private parseWhileStatement(): ASTNode {
    const lineNumber = this.currentToken().lineNumber;
    this.expect(TokenType.WHILE);
    this.expect(TokenType.LPAREN);
    const condition = this.parseExpression();
    this.expect(TokenType.RPAREN);
    this.skipNewlines();
    const body = this.parseStatement();
    return {
      type: "WhileStatement",
      condition,
      body,
      lineNumber,
    };
  }

  private parseBlock(): ASTNode {
    const lineNumber = this.currentToken().lineNumber;
    this.expect(TokenType.LBRACE);
    this.skipNewlines();
    const statements: ASTNode[] = [];
    while (this.currentToken().type !== TokenType.RBRACE) {
      this.skipNewlines();
      if (this.currentToken().type === TokenType.RBRACE) break;
      const stmt = this.parseStatement();
      if (stmt) {
        statements.push(stmt);
      }
      this.skipNewlines();
    }
    this.expect(TokenType.RBRACE);
    return {
      type: "Block",
      statements,
      lineNumber,
    };
  }

  private parseExpressionStatement(): ASTNode {
    const lineNumber = this.currentToken().lineNumber;
    const expr = this.parseExpression();
    if (this.currentToken().type === TokenType.SEMICOLON) {
      this.advance();
    }
    return {
      type: "ExpressionStatement",
      expression: expr,
      lineNumber,
    };
  }

  private parseExpression(): ASTNode {
    // 変数宣言（int x = ...）をサポート
    if (this.currentToken().type === TokenType.INT) {
      this.advance();
      const name = (this.currentToken().value as string);
      this.advance();
      if (this.currentToken().type === TokenType.ASSIGN) {
        this.advance();
        const value = this.parseExpression();
        return {
          type: "Assignment",
          name,
          value,
          lineNumber: this.currentToken().lineNumber,
        };
      }
      return {
        type: "Identifier",
        name,
        lineNumber: this.currentToken().lineNumber,
      };
    }
    return this.parseLogicalOr();
  }

  private parseLogicalOr(): ASTNode {
    let left = this.parseLogicalAnd();
    while (this.currentToken().type === TokenType.OR) {
      const op = this.currentToken().value;
      this.advance();
      const right = this.parseLogicalAnd();
      left = {
        type: "BinaryOp",
        op,
        left,
        right,
        lineNumber: this.currentToken().lineNumber,
      };
    }
    return left;
  }

  private parseLogicalAnd(): ASTNode {
    let left = this.parseEquality();
    while (this.currentToken().type === TokenType.AND) {
      const op = this.currentToken().value;
      this.advance();
      const right = this.parseEquality();
      left = {
        type: "BinaryOp",
        op,
        left,
        right,
        lineNumber: this.currentToken().lineNumber,
      };
    }
    return left;
  }

  private parseEquality(): ASTNode {
    let left = this.parseComparison();
    while (
      this.currentToken().type === TokenType.EQ ||
      this.currentToken().type === TokenType.NEQ
    ) {
      const op = this.currentToken().value;
      this.advance();
      const right = this.parseComparison();
      left = {
        type: "BinaryOp",
        op,
        left,
        right,
        lineNumber: this.currentToken().lineNumber,
      };
    }
    return left;
  }

  private parseComparison(): ASTNode {
    let left = this.parseAdditive();
    while (
      this.currentToken().type === TokenType.LT ||
      this.currentToken().type === TokenType.GT ||
      this.currentToken().type === TokenType.LTE ||
      this.currentToken().type === TokenType.GTE
    ) {
      const op = this.currentToken().value;
      this.advance();
      const right = this.parseAdditive();
      left = {
        type: "BinaryOp",
        op,
        left,
        right,
        lineNumber: this.currentToken().lineNumber,
      };
    }
    return left;
  }

  private parseAdditive(): ASTNode {
    let left = this.parseMultiplicative();
    while (
      this.currentToken().type === TokenType.PLUS ||
      this.currentToken().type === TokenType.MINUS
    ) {
      const op = this.currentToken().value;
      this.advance();
      const right = this.parseMultiplicative();
      left = {
        type: "BinaryOp",
        op,
        left,
        right,
        lineNumber: this.currentToken().lineNumber,
      };
    }
    return left;
  }

  private parseMultiplicative(): ASTNode {
    let left = this.parseUnary();
    while (
      this.currentToken().type === TokenType.MUL ||
      this.currentToken().type === TokenType.DIV ||
      this.currentToken().type === TokenType.MOD
    ) {
      const op = this.currentToken().value;
      this.advance();
      const right = this.parseUnary();
      left = {
        type: "BinaryOp",
        op,
        left,
        right,
        lineNumber: this.currentToken().lineNumber,
      };
    }
    return left;
  }

  private parseUnary(): ASTNode {
    if (
      this.currentToken().type === TokenType.NOT ||
      this.currentToken().type === TokenType.MINUS
    ) {
      const op = this.currentToken().value;
      this.advance();
      const operand = this.parseUnary();
      return {
        type: "UnaryOp",
        op,
        operand,
        lineNumber: this.currentToken().lineNumber,
      };
    }
    return this.parsePostfix();
  }

  private parsePostfix(): ASTNode {
    let expr = this.parsePrimary();
    while (
      this.currentToken().type === TokenType.INCREMENT ||
      this.currentToken().type === TokenType.DECREMENT
    ) {
      const op = this.currentToken().value;
      this.advance();
      expr = {
        type: "PostfixOp",
        op,
        operand: expr,
        lineNumber: this.currentToken().lineNumber,
      };
    }
    return expr;
  }

  private parsePrimary(): ASTNode {
    const token = this.currentToken();
    const lineNumber = token.lineNumber;

    if (token.type === TokenType.NUMBER) {
      this.advance();
      return {
        type: "Number",
        value: token.value,
        lineNumber,
      };
    } else if (token.type === TokenType.IDENTIFIER) {
      const name = token.value as string;
      this.advance();
      if (this.currentToken().type === TokenType.LPAREN) {
        // 関数呼び出し
        this.advance();
        const args: ASTNode[] = [];
        while (this.currentToken().type !== TokenType.RPAREN) {
          args.push(this.parseExpression());
          if (this.currentToken().type === TokenType.COMMA) {
            this.advance();
          }
        }
        this.expect(TokenType.RPAREN);
        return {
          type: "FunctionCall",
          name,
          args,
          lineNumber,
        };
      } else if (this.currentToken().type === TokenType.ASSIGN) {
        this.advance();
        const value = this.parseExpression();
        return {
          type: "Assignment",
          name,
          value,
          lineNumber,
        };
      } else {
        return {
          type: "Identifier",
          name,
          lineNumber,
        };
      }
    } else if (token.type === TokenType.LPAREN) {
      this.advance();
      const expr = this.parseExpression();
      this.expect(TokenType.RPAREN);
      return expr;
    }

    throw new Error(
      `Unexpected token ${token.type} at line ${token.lineNumber}`
    );
  }
}

// ============================================================================
// インタープリタ（実行エンジン）
// ============================================================================

export class ProroInterpreter {
  private state: ProroState;
  private variables: Map<string, number> = new Map();
  private steps: ExecutionStep[] = [];
  private canvasConfig: CanvasConfig;
  private executionLimit: number = 10000; // 無限ループ防止

  constructor(canvasConfig: CanvasConfig) {
    this.canvasConfig = canvasConfig;
    this.state = {
      x: canvasConfig.width / 2,
      y: canvasConfig.height / 2,
      angle: 0,
      speed: 50,
      isMoving: false,
      sensorDetected: false,
    };
  }

  execute(code: string): ExecutionResult {
    try {
      const lexer = new Lexer(code);
      const tokens = lexer.tokenize();

      const parser = new Parser(tokens);
      const ast = parser.parse();

      this.steps = [];
      this.variables.clear();

      for (const node of ast) {
        this.executeNode(node);
        if (this.steps.length > this.executionLimit) {
          throw new Error("実行ステップ数が上限に達しました（無限ループの可能性）");
        }
      }

      return {
        success: true,
        steps: this.steps,
        finalState: this.state,
      };
    } catch (error: any) {
      return {
        success: false,
        error: error.message,
        errorLine: error.lineNumber,
        steps: this.steps,
        finalState: this.state,
      };
    }
  }

  private executeNode(node: ASTNode): any {
    if (node.type === "ExpressionStatement") {
      return this.executeExpression(node.expression);
    } else if (node.type === "IfStatement") {
      const condition = this.evaluateExpression(node.condition);
      if (condition) {
        return this.executeNode(node.thenBranch);
      } else if (node.elseBranch) {
        return this.executeNode(node.elseBranch);
      }
    } else if (node.type === "ForStatement") {
      this.executeExpression(node.init);
      while (this.evaluateExpression(node.condition)) {
        this.executeNode(node.body);
        this.executeExpression(node.update);
      }
    } else if (node.type === "WhileStatement") {
      while (this.evaluateExpression(node.condition)) {
        this.executeNode(node.body);
      }
    } else if (node.type === "Block") {
      for (const stmt of node.statements) {
        this.executeNode(stmt);
      }
    }
  }

  private executeExpression(expr: ASTNode): any {
    if (expr.type === "FunctionCall") {
      return this.executeFunctionCall(expr);
    } else if (expr.type === "Assignment") {
      const value = this.evaluateExpression(expr.value);
      this.variables.set(expr.name, value);
      return value;
    }
    return this.evaluateExpression(expr);
  }

  private evaluateExpression(expr: ASTNode): number {
    if (expr.type === "Number") {
      return expr.value as number;
    } else if (expr.type === "Identifier") {
      return this.variables.get(expr.name) || 0;
    } else if (expr.type === "BinaryOp") {
      const left = this.evaluateExpression(expr.left);
      const right = this.evaluateExpression(expr.right);
      switch (expr.op) {
        case "+":
          return left + right;
        case "-":
          return left - right;
        case "*":
          return left * right;
        case "/":
          return Math.floor(left / right);
        case "%":
          return left % right;
        case "==":
          return left === right ? 1 : 0;
        case "!=":
          return left !== right ? 1 : 0;
        case "<":
          return left < right ? 1 : 0;
        case ">":
          return left > right ? 1 : 0;
        case "<=":
          return left <= right ? 1 : 0;
        case ">=":
          return left >= right ? 1 : 0;
        case "&&":
          return left && right ? 1 : 0;
        case "||":
          return left || right ? 1 : 0;
        default:
          return 0;
      }
    } else if (expr.type === "UnaryOp") {
      const operand = this.evaluateExpression(expr.operand);
      switch (expr.op) {
        case "-":
          return -operand;
        case "!":
          return operand ? 0 : 1;
        default:
          return 0;
      }
    } else if (expr.type === "PostfixOp") {
      if (expr.operand.type === "Identifier") {
        const name = expr.operand.name;
        const current = this.variables.get(name) || 0;
        if (expr.op === "++") {
          this.variables.set(name, current + 1);
        } else if (expr.op === "--") {
          this.variables.set(name, current - 1);
        }
        return current;
      }
    }
    return 0;
  }

  private executeFunctionCall(node: ASTNode): void {
    const name = node.name as string;
    const args = node.args.map((arg: ASTNode) => this.evaluateExpression(arg));

    const lineNumber = node.lineNumber;
    const commandName = name;

    switch (name) {
      case "forward":
        this.forward(args[0] || 0);
        break;
      case "backward":
        this.backward(args[0] || 0);
        break;
      case "turnLeft":
        this.turnLeft(args[0] || 90);
        break;
      case "turnRight":
        this.turnRight(args[0] || 90);
        break;
      case "setSpeed":
        this.setSpeed(args[0] || 50);
        break;
      case "wait":
        this.wait(args[0] || 0);
        break;
      case "objectSensor":
        this.state.sensorDetected = this.objectSensor();
        break;
      case "setAngle":
        this.setAngle(args[0] || 0);
        break;
      default:
        throw new Error(`不明な関数: ${name}`);
    }

    this.recordStep(lineNumber, commandName);
  }

  private forward(distance: number): void {
    const radians = (this.state.angle * Math.PI) / 180;
    const dx = Math.sin(radians) * distance;
    const dy = -Math.cos(radians) * distance;

    this.state.x = Math.max(
      0,
      Math.min(this.canvasConfig.width, this.state.x + dx)
    );
    this.state.y = Math.max(
      0,
      Math.min(this.canvasConfig.height, this.state.y + dy)
    );
  }

  private backward(distance: number): void {
    this.forward(-distance);
  }

  private turnLeft(angle: number): void {
    this.state.angle = (this.state.angle - angle) % 360;
    if (this.state.angle < 0) {
      this.state.angle += 360;
    }
  }

  private turnRight(angle: number): void {
    this.state.angle = (this.state.angle + angle) % 360;
  }

  private setSpeed(speed: number): void {
    this.state.speed = Math.max(1, Math.min(100, speed));
  }

  private wait(ms: number): void {
    // Webでの待機はシミュレーション上では無視（実際の遅延は不要）
  }

  private objectSensor(): boolean {
    // 簡易的なセンサー実装：前方50px以内に壁があるかチェック
    const radians = (this.state.angle * Math.PI) / 180;
    const checkX = this.state.x + Math.sin(radians) * 50;
    const checkY = this.state.y - Math.cos(radians) * 50;

    return (
      checkX < 0 ||
      checkX > this.canvasConfig.width ||
      checkY < 0 ||
      checkY > this.canvasConfig.height
    );
  }

  private setAngle(angle: number): void {
    this.state.angle = angle % 360;
  }

  private recordStep(lineNumber: number, command: string): void {
    this.steps.push({
      lineNumber,
      command,
      state: { ...this.state },
      timestamp: Date.now(),
    });
  }

  getState(): ProroState {
    return { ...this.state };
  }

  setState(state: ProroState): void {
    this.state = { ...state };
  }

  reset(canvasConfig: CanvasConfig): void {
    this.state = {
      x: canvasConfig.width / 2,
      y: canvasConfig.height / 2,
      angle: 0,
      speed: 50,
      isMoving: false,
      sensorDetected: false,
    };
    this.variables.clear();
    this.steps = [];
  }
}
