import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { AlertCircle, Play, RotateCcw, StepForward } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { toast } from "sonner";
import { ProroInterpreter } from "@/lib/proroEngine";

const CANVAS_WIDTH = 600;
const CANVAS_HEIGHT = 400;
const GRID_SIZE = 50;

interface ProroState {
  x: number;
  y: number;
  angle: number;
  speed: number;
  isMoving: boolean;
  sensorDetected: boolean;
}

const SAMPLE_CODES = {
  square: `// 正方形を描く
for (int i = 0; i < 4; i++) {
  forward(100);
  turnRight(90);
}`,
  spiral: `// 螺旋を描く
for (int i = 0; i < 16; i++) {
  forward(50 + i * 5);
  turnRight(30);
}`,
  zigzag: `// ジグザグ移動
for (int i = 0; i < 5; i++) {
  forward(80);
  turnRight(45);
  forward(80);
  turnLeft(45);
}`,
  sensor: `// センサーで障害物検知
forward(100);
if (objectSensor()) {
  turnRight(90);
  forward(50);
}`,
  loop: `// 複雑なループ
for (int i = 1; i <= 3; i++) {
  for (int j = 0; j < i; j++) {
    forward(50);
    turnRight(60);
  }
  forward(100);
}`,
  circle: `// くるくる移動
for (int i = 0; i < 12; i++) {
  forward(50);
  turnRight(30);
}`,
};

export default function Home() {
  const [code, setCode] = useState(SAMPLE_CODES.square);
  const [proroState, setProroState] = useState<ProroState>({
    x: CANVAS_WIDTH / 2,
    y: CANVAS_HEIGHT / 2,
    angle: 0,
    speed: 50,
    isMoving: false,
    sensorDetected: false,
  });
  const [executionResult, setExecutionResult] = useState<any>(null);
  const [isExecuting, setIsExecuting] = useState(false);
  const [isStepMode, setIsStepMode] = useState(false);
  const [currentStepIndex, setCurrentStepIndex] = useState(0);
  const [animationProgress, setAnimationProgress] = useState(0);

  const canvasRef = useRef<HTMLCanvasElement>(null);
  const interpreterRef = useRef<ProroInterpreter>(
    new ProroInterpreter({ width: CANVAS_WIDTH, height: CANVAS_HEIGHT, gridSize: GRID_SIZE })
  );
  const animationFrameRef = useRef<number>();

  // アニメーション処理
  useEffect(() => {
    if (!executionResult || !executionResult.success || isStepMode) {
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
      return;
    }

    let startTime: number | null = null;

    const animate = (timestamp: number) => {
      if (startTime === null) {
        startTime = timestamp;
      }

      const elapsed = timestamp - startTime;
      const duration = Math.max(executionResult.steps.length * 300, 1000);
      const progress = Math.min(elapsed / duration, 1);

      setAnimationProgress(progress);

      if (progress < 1) {
        animationFrameRef.current = requestAnimationFrame(animate);
      } else {
        setProroState(executionResult.finalState);
      }
    };

    animationFrameRef.current = requestAnimationFrame(animate);

    return () => {
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
    };
  }, [executionResult, isStepMode]);

  // キャンバス描画
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    // 背景
    ctx.fillStyle = "#F9FAFB";
    ctx.fillRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);

    // グリッド
    ctx.strokeStyle = "#E5E7EB";
    ctx.lineWidth = 1;
    for (let i = 0; i <= CANVAS_WIDTH; i += GRID_SIZE) {
      ctx.beginPath();
      ctx.moveTo(i, 0);
      ctx.lineTo(i, CANVAS_HEIGHT);
      ctx.stroke();
    }
    for (let i = 0; i <= CANVAS_HEIGHT; i += GRID_SIZE) {
      ctx.beginPath();
      ctx.moveTo(0, i);
      ctx.lineTo(CANVAS_WIDTH, i);
      ctx.stroke();
    }

    // 実行ステップの軌跡を描画
    if (executionResult && executionResult.steps.length > 0) {
      ctx.strokeStyle = "#3B82F6";
      ctx.lineWidth = 2;
      ctx.setLineDash([5, 5]);

      const steps = isStepMode
        ? executionResult.steps.slice(0, currentStepIndex + 1)
        : executionResult.steps;

      if (steps.length > 0) {
        ctx.beginPath();
        ctx.moveTo(steps[0].state.x, steps[0].state.y);
        for (let i = 1; i < steps.length; i++) {
          ctx.lineTo(steps[i].state.x, steps[i].state.y);
        }
        ctx.stroke();
      }

      ctx.setLineDash([]);
    }

    // Proroを描画
    let state: ProroState;
    
    if (isStepMode && executionResult) {
      state = executionResult.steps[Math.min(currentStepIndex, executionResult.steps.length - 1)]?.state || proroState;
    } else if (executionResult && executionResult.success && animationProgress >= 0) {
      // アニメーション中の状態を補間
      const totalSteps = executionResult.steps.length;
      const currentStepFloat = animationProgress * totalSteps;
      const currentStepIdx = Math.floor(currentStepFloat);
      const stepProgress = currentStepFloat - currentStepIdx; // 0-1の補間値
      
      const currentStep = executionResult.steps[Math.min(currentStepIdx, totalSteps - 1)];
      const nextStep = executionResult.steps[Math.min(currentStepIdx + 1, totalSteps - 1)];
      
      if (currentStep && nextStep && stepProgress > 0) {
        // 現在のステップから次のステップへ補間
        const curr = currentStep.state;
        const next = nextStep.state;
        
        // 角度の補間（短い方向で補間）
        let angleDiff = next.angle - curr.angle;
        if (angleDiff > 180) angleDiff -= 360;
        if (angleDiff < -180) angleDiff += 360;
        
        state = {
          x: curr.x + (next.x - curr.x) * stepProgress,
          y: curr.y + (next.y - curr.y) * stepProgress,
          angle: curr.angle + angleDiff * stepProgress,
          speed: curr.speed,
          isMoving: true,
          sensorDetected: false,
        };
      } else {
        state = currentStep?.state || proroState;
      }
    } else {
      state = proroState;
    }

    drawProro(ctx, state);
  }, [proroState, executionResult, currentStepIndex, isStepMode, animationProgress]);

  const drawProro = (ctx: CanvasRenderingContext2D, state: ProroState) => {
    const size = 20;
    const x = state.x;
    const y = state.y;
    const angle = (state.angle * Math.PI) / 180;

    // ロボットの本体
    ctx.fillStyle = "#3B82F6";
    ctx.save();
    ctx.translate(x, y);
    ctx.rotate(angle);
    ctx.fillRect(-size / 2, -size / 2, size, size);

    // 目
    ctx.fillStyle = "#FFFFFF";
    ctx.fillRect(-size / 4, -size / 4, size / 8, size / 8);

    // 方向矢印
    ctx.strokeStyle = "#10B981";
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(0, -size / 2);
    ctx.lineTo(0, size / 2);
    ctx.stroke();

    ctx.restore();

    // 座標表示
    ctx.fillStyle = "#6B7280";
    ctx.font = "12px Inter";
    ctx.fillText(`X: ${Math.round(state.x)}, Y: ${Math.round(state.y)}`, 10, 20);
    ctx.fillText(`Angle: ${Math.round(state.angle)}°`, 10, 35);
  };

  const handleExecute = async () => {
    setIsExecuting(true);
    setCurrentStepIndex(0);
    setIsStepMode(false);
    setAnimationProgress(0);

    try {
      const result = interpreterRef.current.execute(code);
      
      if (result.success) {
        // 初期位置にリセット
        setProroState({
          x: CANVAS_WIDTH / 2,
          y: CANVAS_HEIGHT / 2,
          angle: 0,
          speed: 50,
          isMoving: false,
          sensorDetected: false,
        });
        // 実行結果を設定（これがアニメーション開始トリガー）
        setExecutionResult(result);
        toast.success("コード実行完了！");
      } else {
        setExecutionResult(result);
        toast.error(`エラー: ${result.error}`);
      }
    } catch (error: any) {
      toast.error(`実行エラー: ${error.message}`);
    } finally {
      setIsExecuting(false);
    }
  };

  const handleStepNext = () => {
    if (!executionResult || !executionResult.success) return;

    if (currentStepIndex < executionResult.steps.length - 1) {
      setCurrentStepIndex(currentStepIndex + 1);
    }
  };

  const handleStepMode = () => {
    if (!executionResult || !executionResult.success) {
      toast.error("まずコードを実行してください");
      return;
    }
    setIsStepMode(!isStepMode);
    setCurrentStepIndex(0);
  };

  const handleReset = () => {
    interpreterRef.current.reset({ width: CANVAS_WIDTH, height: CANVAS_HEIGHT, gridSize: GRID_SIZE });
    setProroState({
      x: CANVAS_WIDTH / 2,
      y: CANVAS_HEIGHT / 2,
      angle: 0,
      speed: 50,
      isMoving: false,
      sensorDetected: false,
    });
    setExecutionResult(null);
    setCurrentStepIndex(0);
    setIsStepMode(false);
    setAnimationProgress(0);
    if (animationFrameRef.current) {
      cancelAnimationFrame(animationFrameRef.current);
    }
    toast.success("リセット完了");
  };

  const handleLoadSample = (sampleKey: keyof typeof SAMPLE_CODES) => {
    setCode(SAMPLE_CODES[sampleKey]);
    handleReset();
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-50 p-4 md:p-6">
      <div className="max-w-7xl mx-auto">
        {/* ヘッダー */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-2">
            <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center">
              <span className="text-white font-bold text-lg">P</span>
            </div>
            <h1 className="text-4xl font-bold text-gray-900">Proro V2</h1>
          </div>
          <p className="text-gray-600">
            C++のコードを書いて、2Dのロボット「Proro」を動かそう！
          </p>
        </div>

        {/* メインコンテンツ */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
          {/* 左ペイン: コードエディタ */}
          <Card className="flex flex-col">
            <div className="p-4 border-b border-gray-200">
              <h2 className="text-lg font-semibold text-gray-900">C++ コード</h2>
            </div>
            <div className="flex-1 p-4 overflow-hidden flex flex-col">
              <Textarea
                value={code}
                onChange={(e) => setCode(e.target.value)}
                placeholder="C++コードを入力..."
                className="flex-1 font-mono text-sm resize-none"
              />
            </div>
            <div className="p-4 border-t border-gray-200 space-y-2">
              <p className="text-xs font-semibold text-gray-600 mb-2">サンプル:</p>
              <div className="grid grid-cols-3 gap-2">
                {Object.entries(SAMPLE_CODES).map(([key, _]) => (
                  <Button
                    key={key}
                    variant="outline"
                    size="sm"
                    onClick={() => handleLoadSample(key as keyof typeof SAMPLE_CODES)}
                    className="text-xs"
                  >
                    {key}
                  </Button>
                ))}
              </div>
            </div>
          </Card>

          {/* 右ペイン: コントロール + シミュレーション */}
          <div className="flex flex-col gap-6">
            {/* コントロール */}
            <Card className="p-6 flex flex-col gap-4">
              <h2 className="text-lg font-semibold text-gray-900">コントロール</h2>

              <Button
                onClick={handleExecute}
                disabled={isExecuting}
                className="w-full bg-blue-600 hover:bg-blue-700 text-white"
              >
                <Play className="w-4 h-4 mr-2" />
                実行
              </Button>

              <Button
                onClick={handleStepMode}
                variant="outline"
                className="w-full"
              >
                <StepForward className="w-4 h-4 mr-2" />
                {isStepMode ? "ステップ実行中" : "ステップ実行"}
              </Button>

              {isStepMode && (
                <Button
                  onClick={handleStepNext}
                  variant="secondary"
                  className="w-full"
                  disabled={!executionResult || currentStepIndex >= (executionResult?.steps.length || 0) - 1}
                >
                  次へ
                </Button>
              )}

              <Button
                onClick={handleReset}
                variant="outline"
                className="w-full"
              >
                <RotateCcw className="w-4 h-4 mr-2" />
                リセット
              </Button>
            </Card>

            {/* 実行結果 */}
            {executionResult && (
              <Card className={`p-4 ${executionResult.success ? "bg-green-50" : "bg-red-50"}`}>
                <div className="flex gap-2">
                  <AlertCircle
                    className={`w-5 h-5 flex-shrink-0 ${
                      executionResult.success ? "text-green-600" : "text-red-600"
                    }`}
                  />
                  <div className="flex-1">
                    <p className="font-semibold text-sm text-gray-900">
                      {executionResult.success ? "実行成功" : "エラー"}
                    </p>
                    {executionResult.error && (
                      <p className="text-xs text-gray-700 mt-1">{executionResult.error}</p>
                    )}
                    {executionResult.success && (
                      <p className="text-xs text-gray-700 mt-1">
                        ステップ数: {executionResult.steps.length}
                      </p>
                    )}
                  </div>
                </div>
              </Card>
            )}

            {/* ステップ情報 */}
            {isStepMode && executionResult && executionResult.steps.length > 0 && (
              <Card className="p-4 bg-blue-50">
                <p className="text-xs font-semibold text-gray-600 mb-2">
                  ステップ: {currentStepIndex + 1} / {executionResult.steps.length}
                </p>
                <p className="text-sm font-mono text-gray-900">
                  {executionResult.steps[currentStepIndex]?.command}
                </p>
              </Card>
            )}

            {/* シミュレーション */}
            <Card className="flex flex-col flex-1 min-h-96">
              <div className="p-4 border-b border-gray-200">
                <h2 className="text-lg font-semibold text-gray-900">シミュレーション</h2>
              </div>
              <div className="flex-1 p-4 flex items-center justify-center bg-gray-50">
                <canvas
                  ref={canvasRef}
                  width={CANVAS_WIDTH}
                  height={CANVAS_HEIGHT}
                  className="border-2 border-gray-300 rounded-lg shadow-lg"
                />
              </div>
            </Card>
          </div>
        </div>

        {/* 使い方ガイド */}
        <Card className="p-6 bg-white">
          <h2 className="text-lg font-semibold text-gray-900 mb-4">使い方</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h3 className="font-semibold text-gray-800 mb-2">利用可能なコマンド</h3>
              <ul className="text-sm text-gray-700 space-y-1 font-mono">
                <li>• <span className="text-blue-600">forward(distance)</span> - 前進</li>
                <li>• <span className="text-blue-600">backward(distance)</span> - 後退</li>
                <li>• <span className="text-blue-600">turnLeft(angle)</span> - 左回転</li>
                <li>• <span className="text-blue-600">turnRight(angle)</span> - 右回転</li>
                <li>• <span className="text-blue-600">setSpeed(speed)</span> - 速度設定</li>
                <li>• <span className="text-blue-600">objectSensor()</span> - 障害物検知</li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold text-gray-800 mb-2">制御構文</h3>
              <ul className="text-sm text-gray-700 space-y-1 font-mono">
                <li>• <span className="text-green-600">if (condition) {'{ ... }'}</span></li>
                <li>• <span className="text-green-600">for (int i = 0; i {'<'} n; i++) {'{ ... }'}</span></li>
                <li>• <span className="text-green-600">while (condition) {'{ ... }'}</span></li>
                <li>• 変数: <span className="text-purple-600">int x = 10;</span></li>
                <li>• 演算: <span className="text-purple-600">+, -, *, /, %</span></li>
              </ul>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}
